import React, { useEffect, useRef, memo } from 'react';

function TradingViewWidget() {
  const container = useRef();
  const scriptAppended = useRef(false); // Ref to track if script has been appended

  useEffect(() => {
    // Check if the script has already been appended
    if (!scriptAppended.current) {
      const script = document.createElement("script");
      script.src = "https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js";
      script.type = "text/javascript";
      script.async = true;
      script.innerHTML = `
        {
          "container_id": "watchlist-chart-demo",
          "width": "100%",
          "height": "100%",
          "autosize": true,
          "symbol": "NASDAQ:AAPL",
          "interval": "D",
          "timezone": "exchange",
          "theme": "light",
          "style": "1",
          "withdateranges": true,
          "allow_symbol_change": true,
          "save_image": false,
          "watchlist": [
            "AAPL",
            "IBM",
            "TSLA",
            "AMD",
            "MSFT",
            "GOOG"
          ]
        }`;
      container.current.appendChild(script);
      scriptAppended.current = true; // Update ref to indicate script appended
    }
  }, []);

  return (
    <div className=' h-[70vh] mx-10'>
        <p className=' flex justify-center font-bold uppercase my-8 text-gradient text-2xl'>Track your portfolio</p>
    <div className="tradingview-widget-container" ref={container} style={{ height: "100%", width: "100%" }}>
      <div className="tradingview-widget-container__widget" style={{ height: "calc(100% - 32px)", width: "100%" }}></div>
      
    </div>
    </div>
  );
}

export default memo(TradingViewWidget);

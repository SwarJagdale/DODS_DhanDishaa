import React, { useState,useEffect } from 'react';
import AutomatedSavings from './AutomatedSavings';
// import classNames from 'classnames';

const RoundUpSavings = () => {
  const [currentAmount, setCurrentAmount] = useState(0);
  const [savingsAmount, setSavingsAmount] = useState(0);

  const handleChange = (event) => {
    const amount = parseFloat(event.target.value);
    setCurrentAmount(amount);
  };

  const calculateSavings = () => {
    const roundedAmount = Math.ceil(currentAmount);
    const savings = roundedAmount - currentAmount;
    setSavingsAmount(savings.toFixed(2));
  };

  return (
    <>
    <div className="max-w-md mx-auto">
      <h1 className="text-3xl font-bold text-center mb-4">Round-Up Savings Calculator</h1>
      <div className="flex items-center mb-4">
        <label htmlFor="amount" className="mr-2">Current Amount:</label>
        <input
          type="number"
          id="amount"
          className="rounded border px-2 py-1 w-32"
          value={currentAmount}
          onChange={handleChange}
        />
      </div>
      <button
        className="bg-blue-500 hover:bg-blue-700 text-black font-bold py-2 px-4 rounded"
        onClick={calculateSavings}
      >
        Calculate Savings
      </button>
      {savingsAmount !== 0 && (
        <div className="mt-4">
          <p className="mb-2">You could save: <span className="font-bold">${savingsAmount}</span></p>
          <p className="text-sm">Rounding up to the nearest dollar.</p>
        </div>
      )}
    </div>
    <AutomatedSavings/>
    </>
  );
};

export default RoundUpSavings;

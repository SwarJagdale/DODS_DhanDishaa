import React, { useState, useEffect } from 'react';
// import axios from 'axios';

const AutomatedSavings = () => {
  const [roundUpTransactions, setRoundUpTransactions] = useState([]);
  const [recurringDeposits, setRecurringDeposits] = useState([]);

  useEffect(() => {
    // Simulated data
    const roundUpTransactionsData = [
      { id: 1, amount: 10.5, date: '2024-02-09' },
      { id: 2, amount: 7.2, date: '2024-02-08' },
      { id: 3, amount: 12.8, date: '2024-02-07' },
    ];

    const recurringDepositsData = [
      { id: 1, amount: 50, frequency: 'monthly', startDate: '2024-01-01', endDate: '2024-12-31' },
      { id: 2, amount: 20, frequency: 'weekly', startDate: '2024-01-15', endDate: '2024-12-15' },
    ];

    setRoundUpTransactions(roundUpTransactionsData);
    setRecurringDeposits(recurringDepositsData);
  }, []);

  // Function to render round-up transactions
  const renderRoundUpTransactions = () => {
    return roundUpTransactions.map(transaction => (
      <div key={transaction.id} className="border rounded-md p-4 mb-4">
        <p>Rounded Amount: ${transaction.amount.toFixed(2)}</p>
        <p>Date: {transaction.date}</p>
      </div>
    ));
  };

  // Function to render recurring deposits
  const renderRecurringDeposits = () => {
    return recurringDeposits.map(deposit => (
      <div key={deposit.id} className="border rounded-md p-4 mb-4">
        <p>Amount: ${deposit.amount.toFixed(2)}</p>
        <p>Frequency: {deposit.frequency}</p>
        <p>Start Date: {deposit.startDate}</p>
        <p>End Date: {deposit.endDate}</p>
      </div>
    ));
  };

  return (
    <div className="max-w-lg mx-auto">
      <h2 className="text-xl font-bold mb-4">Round-Up Transactions</h2>
      {roundUpTransactions.length > 0 ? renderRoundUpTransactions() : <p>No round-up transactions found</p>}
      <h2 className="text-xl font-bold mb-4">Recurring Deposits</h2>
      {recurringDeposits.length > 0 ? renderRecurringDeposits() : <p>No recurring deposits found</p>}
    </div>
  );
};

export default AutomatedSavings;

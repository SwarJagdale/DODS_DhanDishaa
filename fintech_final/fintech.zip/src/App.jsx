import { lazy, Suspense } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import NavBar from "./components/Navbar";
import Hero from "./components/Hero"
import RoundUpSavings from "./components/RoundUpSavings";
import './index.css'
import Portfolio from "./components/Portfolio";
// import Test from "./components/test"
// import SmartApi from "./components/SmartApi"
// import { ToastContainer } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";
// import InventoryManagement from "./pages/InventoryManagement";
// import Network from "./pages/Network";
// import Test from "./pages/Test";
// import Rag from "./pages/Rag"
// import Admin from "./pages/Admin";
// const Home = lazy(() => import("./pages/Home"));
// const Shop = lazy(() => import("./pages/Shop"));
// const Cart = lazy(() => import("./pages/Cart"));
// const Product = lazy(() => import("./pages/Product"));
function App() {
  return (
    <Suspense>
      <Router>
       
        <NavBar />
        <Routes>
          <Route path="/" element={<Hero/>} />
          
          <Route path="/savings" element={<RoundUpSavings/>} />
          <Route path="/portfolio" element={<Portfolio/>} />
          {/* <Route path="/stocks" element={<Test/>} /> */}
          {/* <Route path="/shop" element={<Shop />} />
          <Route path="/shop/:id" element={<Product />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/network" element={<Network/>} />
          <Route path="/dashboard" element={<Test/>} />
          <Route path="/rag" element={<Rag/>} />
          <Route path="/admin" element={<Admin/>} /> */}
        </Routes>
        {/* <Footer /> */}
      </Router>
    </Suspense>
  );
}

export default App;

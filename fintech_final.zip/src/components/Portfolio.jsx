import React from 'react'

const Portfolio = () => {
  return (
    <div>
      <div className=' text-white'>
    {/* hello
    <a className='text-white px-32' href="https://diet-recommendation-system.streamlit.app/Diet_Recommendation" target='_blank'>Model</a> */}
    <iframe className='h-screen w-screen' src="http://localhost:8502/" frameborder="0"></iframe>
  </div>
    </div>
  )
}

export default Portfolio

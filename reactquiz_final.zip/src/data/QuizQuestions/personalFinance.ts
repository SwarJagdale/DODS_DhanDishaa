import { Topic } from '.'

export const personalFinance: Topic = {
  topic: 'Personal Finance',
  level: 'Beginner',
  totalQuestions: 20,
  totalScore: 200,
  totalTime: 400,
  questions: [
    {
      question:
        'What is the purpose of creating a budget?',
      choices: [
        'To restrict spending',
        'To track income and expenses',
        'To limit financial growth',
        'To avoid financial planning'
      ],
      type: 'MCQs',
      correctAnswers: [
        'To track income and expenses'
      ],
      score: 10,
    },
    {
      question: 'What is the importance of an emergency fund?',
      choices: ['Emergency funds are unnecessary for financial stability.', 'Emergency funds help cover unexpected expenses and provide financial security.', 'Emergency funds are used for luxury purchases.', 'Emergency funds guarantee investment success.'],
      type: 'MCQs',
      correctAnswers: ['Emergency funds help cover unexpected expenses and provide financial security.'],
      score: 10,
    },
    {
      question:
        'What are the key components of a personal financial plan?',
      choices: [
        'Savings goals and spending limits',
        'Monthly bills and utility payments',
        'Lifestyle choices and entertainment expenses',
        'Daily expenses and impulse purchases'
      ],
      type: 'MCQs',
      correctAnswers: [
        'Savings goals and spending limits'
      ],
      score: 10,
    },
    {
      question:
        'What are the advantages of saving money regularly?',
      choices: [
        'Regular savings prevent financial growth.',
        'Regular savings ensure a limited lifestyle.',
        'Regular savings provide financial security and help achieve financial goals.',
        'Regular savings lead to financial instability.'
      ],
      type: 'MCQs',
      correctAnswers: [
        'Regular savings provide financial security and help achieve financial goals.'
      ],
      score: 10,
    },
    {
      question: 'How can individuals improve their credit score?',
      choices: [
        'By ignoring credit card payments',
        'By applying for multiple loans at once',
        'By making timely bill payments and managing credit responsibly',
        'By defaulting on loan payments'
      ],
      type: 'MCQs',
      correctAnswers: [
        'By making timely bill payments and managing credit responsibly'
      ],
      score: 10,
    },
    {
      question: 'What is the significance of setting financial goals?',
      choices: [
        'Financial goals limit personal growth.',
        'Financial goals provide a framework for effective financial planning and decision-making.',
        'Financial goals are irrelevant in personal finance.',
        'Financial goals guarantee financial success.'
      ],
      type: 'MCQs',
      correctAnswers: [
        'Financial goals provide a framework for effective financial planning and decision-making.'
      ],
      score: 10,
    },
    {
      question: 'How can individuals reduce unnecessary expenses?',
      choices: [
        'By increasing spending on luxury items',
        'By disregarding budgeting techniques',
        'By tracking expenses and eliminating non-essential purchases',
        'By avoiding financial planning'
      ],
      type: 'MCQs',
      correctAnswers: [
        'By tracking expenses and eliminating non-essential purchases'
      ],
      score: 10,
    },
    {
      question: 'What is the purpose of retirement planning?',
      choices: [
        'Retirement planning is unnecessary for financial stability.',
        'Retirement planning ensures financial security during retirement years.',
        'Retirement planning limits financial growth.',
        'Retirement planning guarantees investment success.'
      ],
      type: 'MCQs',
      correctAnswers: [
        'Retirement planning ensures financial security during retirement years.'
      ],
      score: 10,
    },
    {
      question: 'What are the benefits of investing in a diversified portfolio?',
      choices: [
        'Diversified portfolios increase investment risk.',
        'Diversified portfolios provide limited returns.',
        'Diversified portfolios ensure financial instability.',
        'Diversified portfolios reduce investment risk and maximize returns.'
      ],
      type: 'MCQs',
      correctAnswers: [
        'Diversified portfolios reduce investment risk and maximize returns.'
      ],
      score: 10,
    },
    {
      question: 'How can individuals manage debt effectively?',
      choices: [
        'By borrowing excessively',
        'By ignoring debt payments',
        'By making timely payments and prioritizing high-interest debt',
        'By defaulting on loan payments'
      ],
      type: 'MCQs',
      correctAnswers: [
        'By making timely payments and prioritizing high-interest debt'
      ],
      score: 10,
    },
    {
      question: 'What are the characteristics of a healthy financial plan?',
      choices: [
        'A healthy financial plan focuses solely on spending.',
        'A healthy financial plan lacks clear financial goals.',
        'A healthy financial plan includes emergency savings, debt management, and retirement planning.',
        'A healthy financial plan ignores budgeting.'
      ],
      type: 'MCQs',
      correctAnswers: [
        'A healthy financial plan includes emergency savings, debt management, and retirement planning.'
      ],
      score: 10,
    },
    {
      question: 'What is the importance of monitoring personal finances?',
      choices: [
        'Monitoring personal finances is unnecessary for financial stability.',
        'Monitoring personal finances helps identify opportunities for additional spending.',
        'Monitoring personal finances ensures financial instability.',
        'Monitoring personal finances helps individuals stay on track with financial goals.'
      ],
      type: 'MCQs',
      correctAnswers: [
        'Monitoring personal finances helps individuals stay on track with financial goals.'
      ],
      score: 10,
    },
    {
      question: 'How can individuals build wealth over time?',
      choices: [
        'By overspending and ignoring savings.',
        'By making impulsive financial decisions.',
        'By investing regularly and saving consistently over time.',
        'By avoiding financial planning.'
      ],
      type: 'MCQs',
      correctAnswers: [
        'By investing regularly and saving consistently over time.'
      ],
      score: 10,
    },
    {
      question: 'What are the potential benefits of automating finances?',
      choices: [
        'Automating finances increases financial stress.',
        'Automating finances leads to financial instability.',
        'Automating finances reduces the need for financial planning.',
        'Automating finances streamlines bill payments and savings contributions.'
      ],
      type: 'MCQs',
      correctAnswers: [
        'Automating finances streamlines bill payments and savings contributions.'
      ],
      score: 10,
    },
    {
      question: 'What are the potential risks of borrowing money?',
      choices: [
        'Borrowing money improves credit scores.',
        'Borrowing money increases financial security.',
        'Borrowing money may lead to debt accumulation and financial stress.',
        'Borrowing money guarantees investment success.'
      ],
      type: 'MCQs',
      correctAnswers: [
        'Borrowing money may lead to debt accumulation and financial stress.'
      ],
      score: 10,
    },
    {
      question: 'What are the key factors to consider when selecting financial products?',
      choices: [
        'Interest rates and loan terms',
        'Luxury features and brand reputation',
        'Impulse purchases and spending habits',
        'Past performance and investment returns'
      ],
      type: 'MCQs',
      correctAnswers: [
        'Interest rates and loan terms'
      ],
      score: 10,
    },
    {
      question: 'How can individuals prioritize financial goals?',
      choices: [
        'By ignoring financial goals',
        'By procrastinating on financial decisions',
        'By evaluating goals based on importance and feasibility',
        'By disregarding budgeting techniques'
      ],
      type: 'MCQs',
      correctAnswers: [
        'By evaluating goals based on importance and feasibility'
      ],
      score: 10,
    },
    {
      question: 'What is the significance of financial education in personal finance?',
      choices: [
        'Financial education is unnecessary for financial stability.',
        'Financial education helps individuals make informed financial decisions.',
        'Financial education limits personal growth.',
        'Financial education guarantees investment success.'
      ],
      type: 'MCQs',
      correctAnswers: [
        'Financial education helps individuals make informed financial decisions.'
      ],
      score: 10,
    },
    {
      question: 'What are the potential benefits of seeking professional financial advice?',
      choices: [
        'Seeking professional financial advice leads to financial instability.',
        'Seeking professional financial advice guarantees investment success.',
        'Seeking professional financial advice helps individuals navigate complex financial decisions.',
        'Seeking professional financial advice limits financial growth.'
      ],
      type: 'MCQs',
      correctAnswers: [
        'Seeking professional financial advice helps individuals navigate complex financial decisions.'
      ],
      score: 10,
    },
  ],
}



type QuizTopic = {
  title: string

  disabled?: boolean
}

export const quizTopics: QuizTopic[] = [
  {
    title: 'Mutual Funds',

  },
  {
    title: 'Investment',
 },
  {
    title: 'Personal Finance',

  },

]
